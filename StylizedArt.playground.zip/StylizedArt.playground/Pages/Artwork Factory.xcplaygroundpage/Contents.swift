
/*:
# Artwork Factory 🏭
 At the end of this page you will have created a fascinating Artwork. 🤯
 
---
 */
//: Enter Artist Name for your artwork👩‍🎨
  var name = "<#Write Your Artist Name#>"



/*:

>  Wait for the animation to finish after clicking any button.🙂
 */
/*:
 Things to pay attention while creating your work
 - It is important that the objects you choose match the background.
 - You can choose multiple effects and objects.But I suggest you choose 3-4 objects and max 2 effects.

 ---
 
 In Style Transfer Section

 - If you are making abstract-style artwork, select the one on the left,
 - If you are making landscape-style artwork, choose StarryNight(middle),
 - If you are making a different artwork, I suggest you choose the one on the right.
 */
/*:
I hope it will be a playground that you impress. Have Fun. 🖌
*/
import SwiftUI
import PlaygroundSupport



struct MainView: View{
    @State var step = -1

    var body: some View{
        ZStack{
            
            ContentView(step: $step)
            if step <= 0 {
                ZStack{
                    VStack{
                        Image(uiImage: UIImage(named: "Memoji.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 100)
                            .padding()
                        LinearGradient(gradient: Gradient(colors: [Color.red, Color.gray, Color.purple ]), startPoint: .topLeading, endPoint: .bottomTrailing)
                            .mask(Text(". . .")
                                    .foregroundColor(.black)
                                    .fontWeight(.heavy)
                                    .font(.system(size: 40))
                                    .padding())
                            .shadow(radius: 3)
                            .frame(height: 30).offset(y: -10)
                        LinearGradient(gradient: Gradient(colors: [Color.purple, Color.gray, Color.red ]), startPoint: .topLeading, endPoint: .bottomTrailing)
                            .mask(Text("🏭 Artwork Factory 🏭")
                                    .foregroundColor(.black)
                                    .fontWeight(.heavy)
                                    .font(.system(size: 25))
                                    .padding())
                            .shadow(radius: 3)
                            .frame(height: 30)
                        Text("Follow the steps on this page to create an Artwork\n that will decorate the walls of your home. Hope you like it and \nhave a nice experience.🤩")
                                .foregroundColor(.black)
                                .fontWeight(.semibold)
                                .multilineTextAlignment(.center)
                        Spacer()
                        HStack{
                            Spacer()
                            Button {
                                step += 1
                            } label: {
                                ZStack{
                                    Color.black
                                        .opacity(0.9)
                                        .frame(width: 70, height: 30)
                                    Image(systemName: "arrow.forward")
                                        .foregroundColor(.white)
                                }
                            }.cornerRadius(2)

                        }
                    }.padding()
                    
                }.offset(x: step < 0 ? 0 : -900 )
                
                
            }
        }
    }
}

struct ContentView: View{
    @State var rect: CGRect = .zero
    @State var selectedBg : UIImage?
    @State var result : UIImage? = nil


    @Binding var step : Int
    @State var subjects = ["blueLine.png" : false , "city.png" : false , "cloud.png" : false , "linePeople.png" : false , "mountainObject.png" : false , "road.png" : false , "thinking.png" : false , "tower.png" : false]
    @State var effects = ["bokeh.png" : false , "fire.png" : false , "fog.png" : false , "rain.png" : false , "stars.png" : false , "water.png" : false]
    var body: some View{
        ZStack{
            Color.white
            if step <= 1{
                Background(selectedBg: $selectedBg, step: $step)
                    .offset(x: PageVariables(step: $step).backgroundPage ? 0 : 900)
                    .animation(.easeOut)
            }
            //Object
            if step <= 3{
                if step <= 2{
                    Object(subjects: $subjects)
                        .offset(x: PageVariables(step: $step).itemPage ? 0 : -900)
                        .animation(.easeOut)
                }
                Effects(effects: $effects)
                    .offset(x: PageVariables(step: $step).effectPage ? 0 : 900)
                    .animation(.easeInOut)
            }
            if step >= 2 && step <= 4 {
                HStack{
                    artwork.animation(.easeInOut(duration: 0.6))
                    Text("You did it.🥳\nBut now, it will get better.")
                        .foregroundColor(.black)
                        .bold()
                        .multilineTextAlignment(.center)
                }
                .offset(y: PageVariables(step: $step).resultPage ? 0 : -900)
                .animation(.easeInOut(duration: 1))
                
            }
            if step >= 3 && step <= 5 {
                VStack{
                    Text("Select the art you want to transfer style!🌃")
                        .foregroundColor(.black)
                        .bold()
                    HStack{
                        Image(uiImage: UIImage(named: "abstractPainting.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 100 )
                            .border(Color.black, width: 5)
                            .onTapGesture {
                               
                                setAbstractPainting()
                                step += 1
                            }
                        Image(uiImage: UIImage(named: "starrynight.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 100 )
                            .border(Color.black, width: 5)
                            .onTapGesture {
                                setStarryNightStyle()
                                step += 1
                            }
                        Image(uiImage: UIImage(named: "ninfee.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 150, height: 100)
                            .border(Color.black, width: 5)
                            .onTapGesture {
                                setNinfeeStyle()
                                step += 1
                            }
                    }
                    .padding()
                    Text("There may be slowdowns during style transfer!")
                        .foregroundColor(.black)
                        .fontWeight(.light)
                }
                .offset(y: PageVariables(step: $step).styleTransferPage ? 0 : 900)
                .animation(.easeOut(duration: 0.5))
            }
            if step >= 4 && step <= 6 {
                ZStack{
                    VStack{
                        Image(uiImage: result ?? UIImage(named: "bokeh.png")!)
                            .resizable()
                            .frame(width: 400, height: 250).border(Color.black, width: 5)
                        
                        HStack(spacing: 0){
                            Text("Created in")
                                .foregroundColor(.black)
                                .fontWeight(.heavy)
                            LinearGradient(gradient: Gradient(colors: [Color.init(#colorLiteral(red: 0.7796346545, green: 0.6019737124, blue: 0.8332694173, alpha: 1)), Color.init(#colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)) ]), startPoint: .leading, endPoint: .trailing)
                                .mask(
                                    Text("StylizedArt")
                                        .fontWeight(.heavy)
                                        .foregroundColor(.white)
                                        )
                                .frame(width: 110, height: 30)
                        }
                        
                        
                        //Don't fill this up, this is for check.
                        Text(name == "<#Write Your Artist Name#>" ? "" : "by \(name)")
                            .fontWeight(.light)
                            .foregroundColor(.black)
                        
                    }
                    
                        
                }
                .offset(y: PageVariables(step: $step).stylizedArt ? 0 : -900 )
                .animation(.easeOut(duration: 2))
            }
            
            
            if !(step >= 4) {
                VStack{
                   Spacer()
                   HStack{
                       Spacer()
                       Button {
                        step += 1
                        if step == 4 {
                            result = artwork.asImage(size: CGSize(width: 400, height: 250))
                        }
                        if step == 5 {
                            selectedBg = nil
                        }
                                       
                       } label: {
                           ZStack{
                               Color.black
                                   .opacity(0.9)
                                   .frame(width: 70, height: 30)
                               Image(systemName: "arrow.forward")
                                   .foregroundColor(.white)
                           }
                       }.offset(x: selectedBg != nil ?  0 : 300)
                       .cornerRadius(2)
                   }
               }.padding()
            }
        }
    }
    var artwork: some View{
        ZStack{
            Image(uiImage: (selectedBg ?? UIImage(named: "mountain.png"))!)
            ResultObject(subjects: $subjects)
            ResultEffect(effects: $effects)
        }.frame(width: 400, height: 250)
    }
    func setNinfeeStyle(){
        if let pickedImage = result {
            
        let model = try! Ninfee.init(contentsOf: Ninfee.urlOfModelInThisBundle)
            
            
            if let image = pixelBuffer(from: pickedImage) {
                do {
                    let predictionOutput = try model.prediction(image: image)

                    let ciImage = CIImage(cvPixelBuffer: predictionOutput.stylizedImage)
                    let tempContext = CIContext(options: nil)
                    let tempImage = tempContext.createCGImage(ciImage, from: CGRect(x: 0, y: 0, width: CVPixelBufferGetWidth(predictionOutput.stylizedImage), height: CVPixelBufferGetHeight(predictionOutput.stylizedImage)))
                    result = UIImage(cgImage: tempImage!)
                } catch let error as NSError {
                    print("CoreML Model Error: \(error)")
                }
            }
        }
    }
    func setStarryNightStyle(){
        if let pickedImage = result {
            
        let model = try! StarryNightStyle.init(contentsOf: StarryNightStyle.urlOfModelInThisBundle)
            
            
            if let image = pixelBuffer(from: pickedImage) {
                do {
                    let predictionOutput = try model.prediction(image: image)

                    let ciImage = CIImage(cvPixelBuffer: predictionOutput.stylizedImage)
                    let tempContext = CIContext(options: nil)
                    let tempImage = tempContext.createCGImage(ciImage, from: CGRect(x: 0, y: 0, width: CVPixelBufferGetWidth(predictionOutput.stylizedImage), height: CVPixelBufferGetHeight(predictionOutput.stylizedImage)))
                    result = UIImage(cgImage: tempImage!)
                } catch let error as NSError {
                    print("CoreML Model Error: \(error)")
                }
            }
        }
    }
    func setAbstractPainting(){
        if let pickedImage = result {
            
        let model = try! AbstractPainting.init(contentsOf: AbstractPainting.urlOfModelInThisBundle)
            
            
            if let image = pixelBuffer(from: pickedImage) {
                do {
                    let predictionOutput = try model.prediction(image: image)

                    let ciImage = CIImage(cvPixelBuffer: predictionOutput.stylizedImage)
                    let tempContext = CIContext(options: nil)
                    let tempImage = tempContext.createCGImage(ciImage, from: CGRect(x: 0, y: 0, width: CVPixelBufferGetWidth(predictionOutput.stylizedImage), height: CVPixelBufferGetHeight(predictionOutput.stylizedImage)))
                    result = UIImage(cgImage: tempImage!)
                } catch let error as NSError {
                    print("CoreML Model Error: \(error)")
                }
            }
        }
    }
}


struct PageVariables {
    @Binding var step : Int
    static var emojiIndex = 0
    var backgroundPage : Bool {
            if step == 0  {
                return true
            }else{
                return false
            }
            }
    var itemPage : Bool {
            if step == 1  {
                return true
            }else{
                return false
            }
        }
    var effectPage : Bool{
            if step == 2  {
                return true
            }else{
                return false
            }
        }
    var resultPage : Bool {
            if step == 3  {
                return true
            }else{
                return false
            }
        }
    var styleTransferPage : Bool {
            if step == 4  {
                return true
            }else{
                return false
            }
    }
    var stylizedArt : Bool {
            if step == 5  {
                return true
            }else{
                return false
            }
        }
}



struct Background: View {
    @Binding var selectedBg : UIImage?
    @Binding var step : Int
    var body: some View {
        ZStack{
            VStack{
                
                HStack{
                    Text("Select Background")
                        .font(.system(size: 25))
                        .fontWeight(.black)
                    Spacer()
                }
                Spacer()
            }.padding([.leading , .top ] , 20)
            
            
            // Background
            LazyVStack{
                HStack{
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "pinkEf.png")!)
                            .resizable().scaledToFit()
                            .frame(width: 100, height: 75)
                    }.onTapGesture {
                            selectedBg =  UIImage(named: "pinkEf.png")
                            step += 1
                        
                    }
                    .frame(width: 120, height: 100)
                    .shadow(radius: 10 )
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "Sea.png")!).resizable().scaledToFit().frame(width: 100, height: 75)
                            
                    }
                    .frame(width: 120, height: 100)
                    .shadow(radius: 10 )
                    .onTapGesture {
                            selectedBg =  UIImage(named: "Sea.png")
                            step += 1
                        
                }
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "whiteBg.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 75)
                            
                    }
                    .frame(width: 120, height: 100)
                    .shadow(radius: 10 )
                    .onTapGesture {
                            selectedBg =  UIImage(named: "whiteBg.png")
                            step += 1
                        
                    }
                   
                }
                HStack{
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "autumn.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 75)
                            
                    }
                    .frame(width: 120, height: 100)
                    .shadow(radius: 10 )
                    .onTapGesture {
                            selectedBg =  UIImage(named: "autumn.png")
                            step += 1
                        
                    }
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "canyon.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 75)
                            
                    }
                    .frame(width: 120, height: 100)
                    .shadow(radius: 10 )
                    .onTapGesture {
                            selectedBg =  UIImage(named: "canyon.png")
                            step += 1
                        
                    }
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "mountain.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 75)
                            
                    }
                    .frame(width: 120, height: 100)
                    .shadow(radius: 10 )
                    .onTapGesture {
                            selectedBg =  UIImage(named: "mountain.png")
                            step += 1
        
                    }
                }
                
            }
              
        }
    
    }
}

struct Object : View {
    @Binding var subjects : [String : Bool]
    var body: some View{
        
        ZStack{
            Color.white
            VStack(alignment: .leading){
                HStack{
                    
                    Text("Select Object")
                        .font(.system(size: 25))
                        .fontWeight(.black)
                    
                    Spacer()
                }
                
                Text("You can selecet more than one object!")
                    .font(.system(size: 15))
                    .fontWeight(.semibold)
                Spacer()
            }.padding([.leading , .top ] , 20)
            
            
            LazyVStack{
                LazyHStack{
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "blueLine.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: subjects["blueLine.png"]! ? -300 : 0)
                    .onTapGesture {
                            subjects["blueLine.png"]?.toggle()
                    }
                    
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "city.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: subjects["city.png"]! ? -300 : 0)
                    .onTapGesture {
                            subjects["city.png"]?.toggle()
                    }
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "cloud.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: subjects["cloud.png"]! ? -300 : 0)
                    .onTapGesture {
                            subjects["cloud.png"]?.toggle()
                    }
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "tower.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: subjects["tower.png"]! ? -300 : 0)
                    .onTapGesture {
                            subjects["tower.png"]?.toggle()
                    }
                }
                LazyHStack{
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "linePeople.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: subjects["linePeople.png"]! ? 300 : 0)
                    .onTapGesture {
                            subjects["linePeople.png"]?.toggle()
                    }
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "mountainObject.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: subjects["mountainObject.png"]! ? 300 : 0)
                    .onTapGesture {
                            subjects["mountainObject.png"]?.toggle()
                    }
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "road.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: subjects["road.png"]! ? 300 : 0)
                    .onTapGesture {
                            subjects["road.png"]?.toggle()
                    }
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "thinking.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: subjects["thinking.png"]! ? 300 : 0)
                    .onTapGesture {
                            subjects["thinking.png"]?.toggle()
                    }
                }
            }
            
            
        }
        
    }
}




struct Effects : View {
    @Binding var effects : [String : Bool]

    var body: some View{
        
        ZStack{
            Color.white
            VStack(alignment: .leading){
                HStack{
                    Text("Select Effect")
                        .font(.system(size: 25))
                        .fontWeight(.black)
                    Spacer()
                }
                Text("You can selecet more than one effect!")
                    .font(.system(size: 15))
                    .fontWeight(.semibold)
                Spacer()
            }.padding([.leading , .top ] , 20)
            LazyVStack{
                LazyHStack{
                    ZStack{
                        Color.white
                        Color.gray.frame(width: 90, height: 65)
                        Image(uiImage: UIImage(named: "bokeh.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: effects["bokeh.png"]! ? -400 : 0)
                    .onTapGesture {
                            effects["bokeh.png"]?.toggle()
                    }
                    
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "fire.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: effects["fire.png"]! ? -400 : 0)
                    .onTapGesture {
                            effects["fire.png"]?.toggle()
                    }
                    ZStack{
                        Color.white
                        Color.gray.frame(width: 90, height: 65)
                        Image(uiImage: UIImage(named: "fog.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: effects["fog.png"]! ? -400 : 0)
                    .onTapGesture {
                            effects["fog.png"]?.toggle()
                    }
                    
                }
                LazyHStack{
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "rain.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: effects["rain.png"]! ? 400 : 0)
                    .onTapGesture {
                            effects["rain.png"]?.toggle()
                    }
                    
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "stars.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: effects["stars.png"]! ? 400 : 0)
                    .onTapGesture {
                            effects["stars.png"]?.toggle()
                    }
                    ZStack{
                        Color.white
                        Image(uiImage: UIImage(named: "water.png")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                    }.frame(width: 100, height: 100)
                    .shadow(radius: 10 )
                    .offset(y: effects["water.png"]! ? 400 : 0)
                    .onTapGesture {
                            effects["water.png"]?.toggle()
                    }
                    
                }
            }
           
        }
    }
    
}



struct ResultObject : View{
    @Binding var subjects : [String : Bool]
    var body: some View{
        ZStack{
            if subjects["mountainObject.png"]! {
                Image(uiImage: UIImage(named: "mountainObject.png")!)
            }
            if subjects["road.png"]! {
                Image(uiImage: UIImage(named: "road.png")!)
            }
            if subjects["blueLine.png"]! {
                Image(uiImage: UIImage(named: "blueLine.png")!)
            }
            if subjects["city.png"]! {
                Image(uiImage: UIImage(named: "city.png")!)
            }
            if subjects["cloud.png"]! {
                Image(uiImage: UIImage(named: "cloud.png")!)
            }
            if subjects["tower.png"]! {
                Image(uiImage: UIImage(named: "tower.png")!)
            }
            if subjects["thinking.png"]! {
                Image(uiImage: UIImage(named: "blueLine.png")!)
            }
            if subjects["linePeople.png"]! {
                Image(uiImage: UIImage(named: "linePeople.png")!)
            }
        }
    }
}
struct ResultEffect : View{
    @Binding var effects : [String : Bool]
    var body: some View{
        ZStack{
            if effects["fire.png"]!{
                Image(uiImage: UIImage(named: "fire.png")!)
            }
            if effects["water.png"]!{
                Image(uiImage: UIImage(named: "water.png")!)
            }
            if effects["stars.png"]!{
                Image(uiImage: UIImage(named: "stars.png")!)
            }
            if effects["rain.png"]!{
                Image(uiImage: UIImage(named: "rain.png")!)
            }
            if effects["fog.png"]!{
                Image(uiImage: UIImage(named: "fog.png")!)
            }
            
            if effects["bokeh.png"]!{
                Image(uiImage: UIImage(named: "bokeh.png")!)
            }
        }
    }
}




extension UIView {
    func asImage() -> UIImage {
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        return UIGraphicsImageRenderer(size: self.layer.frame.size, format: format).image { context in
            self.drawHierarchy(in: self.layer.bounds, afterScreenUpdates: true)
        }
    }
}


extension View {
    func asImage(size: CGSize) -> UIImage {
        let controller = UIHostingController(rootView: self)
        controller.view.bounds = CGRect(origin: .zero, size: size)
        let image = controller.view.asImage()
        return image
    }
}


func pixelBuffer(from image: UIImage) -> CVPixelBuffer? {
    
    UIGraphicsBeginImageContextWithOptions(CGSize(width: 512, height: 512), true, 2.0)
    image.draw(in: CGRect(x: 0, y: 0, width: 512, height: 512))
    _ = UIGraphicsGetImageFromCurrentImageContext()!
    UIGraphicsEndImageContext()

    let attrs = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue, kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
    var pixelBuffer : CVPixelBuffer?
    let status = CVPixelBufferCreate(kCFAllocatorDefault, 512, 512, kCVPixelFormatType_32ARGB, attrs, &pixelBuffer)
    guard (status == kCVReturnSuccess) else {
        return nil
    }

    CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
    let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer!)

    let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
    let context = CGContext(data: pixelData, width: 512, height: 512, bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer!), space: rgbColorSpace, bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue)

    context?.translateBy(x: 0, y: 512)
    context?.scaleBy(x: 1.0, y: -1.0)

    UIGraphicsPushContext(context!)
    image.draw(in: CGRect(x: 0, y: 0, width: 512, height: 512))
    UIGraphicsPopContext()
    CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))

    return pixelBuffer
}


PlaygroundPage.current.setLiveView(MainView().frame(width: 600, height: 400))


