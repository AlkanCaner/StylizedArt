import SwiftUI
import PlaygroundSupport



/*:
# What is StylizedArt? 🌃
On this page, you will get information about StylizedArt and experience Style Transfer with a real picture.🖼

---
 
 ### Examples from StylizedArt
   
![StarryNight](example1.png)
![Ninfee](example3.png)
![AbstractPainting](example2.png)
 
 */


//: [Go to Artwork Factory](@next)

struct ContentView : View {
    @State var page : Int = 0
    var body: some View{
        ZStack{
            Color.black.opacity(0.9)
            
            if page == 0 {
                CardView(page: $page)
            }
            if page == 1 {
                TransferView().transition(.slide)
            }
           

        }
        
    }
}


//: **Style transfer** experience takes place in this structure.
struct TransferView : View{
    @State var myImage = UIImage(named: "sampleImage.jpg")
    @State var showImage = false
    @State var lastPage = false

    var body: some View{
       ZStack{
        Color.black.edgesIgnoringSafeArea(.all)
        VStack{
            HStack{
                Image(uiImage: UIImage(named: "sampleImage.jpg")!)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 150)
                
                if showImage {
                    VStack{
                        Image(uiImage: UIImage(named: "starrynight.jpg")!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 40, height: 40)
                            .padding()
                        Image(systemName: "chevron.right.2")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 30, height: 30)
                            .foregroundColor(.white)
                        
                    }
                    Image(uiImage: myImage!)
                        .resizable()
                        
                        .frame(width: 200, height: 150)
                }
            }
            Button(action: {
                withAnimation {
                    set()
                    showImage = true
                }
            }, label: {
                ZStack{
                  
                    Image(systemName: "wand.and.rays.inverse")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .foregroundColor(.white)
                        .padding(.top)
                    Image(systemName: "wand.and.rays.inverse")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .foregroundColor(.white)
                        .padding(.top)
                        .blur(radius: 5)
                    
                }
                
            })
            ZStack{
                VStack{
                    Text("Click on the wand for Style Transfer.")
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                    Text("When you click on the wand,\nplayground may slow down for a short time!!")
                        .fontWeight(.light)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                }
                .padding()
                .offset(x: showImage ? -600 : 0 , y: -20)
                VStack{
                    Text("And Style Transfer has been done.🤯")
                        .fontWeight(.black)
                        .foregroundColor(.white)
                    Text("Now you can press the wand as much as you want and\n to beautify your Artworks.🏆")
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                    HStack{
                        Spacer()
                        Button {
                            withAnimation(.easeInOut(duration: 1.5)) {
                                lastPage.toggle()
                            }
                            
                        } label: {
                            ZStack{
                                Color.white.opacity(0.9).frame(width: 70, height: 30)
                                Image(systemName: "arrow.forward")
                                    .foregroundColor(.black)
                            }
                        }
                    }
                }.padding()
                .offset(x: showImage ? 0 : 600 )
            }
        }.offset(y: lastPage ? 400 : 20)
        HStack{
            Image(uiImage: myImage!)
                .resizable()
                .scaledToFit()
                .frame(width: 300, height: 225)
            VStack{
                Text("You created this.😎")
                    .bold()
                    .foregroundColor(.white)
                    .offset(y: lastPage ? 0 : -500)
                Text("In the next Page, you can create a new Artwork with details.🥳")
                    .fontWeight(.light)
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .offset(y: lastPage ? 0 : -500)
            }.padding(.trailing)
            
            
                
        }.offset(y: lastPage ? 0 : -400)
       }
        
    }
    
//: This function enables _Artificial Intelligence_ to work.🤖
    func set(){
        if let pickedImage = myImage {
            
        let model = try! StarryNightStyle.init(contentsOf: StarryNightStyle.urlOfModelInThisBundle)
            
            
            if let image = pixelBuffer(from: pickedImage) {
                do {
                    let predictionOutput = try model.prediction(image: image)

                    let ciImage = CIImage(cvPixelBuffer: predictionOutput.stylizedImage)
                    let tempContext = CIContext(options: nil)
                    let tempImage = tempContext.createCGImage(ciImage, from: CGRect(x: 0, y: 0, width: CVPixelBufferGetWidth(predictionOutput.stylizedImage), height: CVPixelBufferGetHeight(predictionOutput.stylizedImage)))
                    myImage = UIImage(cgImage: tempImage!)
                } catch let error as NSError {
                    print("CoreML Model Error: \(error)")
                }
            }
        }
    }

}

struct Variables {
    @Binding var step : Int
    public var pass : Bool {
        if step == 3 {
            return true
        }else{
            return false
        }
        }
    
}




//: Writings and animations take place in this structure.
struct CardView: View{
    @Binding var page : Int
    
    @State var isRun = false
    @State var isRun2 = false
    

    @State var subtext = ""

   
    @State var step = 0
    @State var pad : CGFloat = 0


    var body: some View{
        ZStack{
            Color.black
            if !isRun2 {
                VStack{
                    HStack{
                        ZStack{
                            Text("WWDC21").bold().foregroundColor(.white).font(.system(size: 20)).blur(radius: 3)
                            Text("WWDC21").bold().foregroundColor(.white).font(.system(size: 20))
                            
                        }
                        Spacer()
                        ZStack{
                            Text("").bold().foregroundColor(.white).font(.system(size: 30)).blur(radius: 3)
                            Text("").bold().foregroundColor(.white).font(.system(size: 30))
                            
                        }
                    }.padding([.top,.leading,.trailing])
                    
                    ZStack{
                        HStack{
                            Text("Glow").bold().foregroundColor(.purple).blur(radius: 3).font(.system(size: 20))
                            Text("and").bold().blur(radius: 3).foregroundColor(.white).font(.system(size: 20))
                            Text("behold.").bold().foregroundColor(.pink).blur(radius: 3).font(.system(size: 20))
                            Spacer()
                        }
                        HStack{
                            Text("Glow").bold().foregroundColor(.purple).font(.system(size: 20))
                            Text("and").bold().foregroundColor(.white).font(.system(size: 20))
                            Text("behold.").bold().foregroundColor(.pink).font(.system(size: 20))
                            Spacer()
                        }
                    }.padding(.leading)
                    
                        Spacer()
                        VStack{
                        LinearGradient(gradient: Gradient(colors: [Color.purple, Color.white, Color.red]), startPoint: .leading, endPoint: .trailing)
                            .mask(Text("StylizedArt")
                                    .bold()
                                    .foregroundColor(.white)
                                    .font(.system(size: 25)))
                        LinearGradient(gradient: Gradient(colors: [Color.red, Color.purple]), startPoint: .leading, endPoint: .trailing)
                            .mask(Text("A.Alkan Caner")
                                    .bold()
                                    .foregroundColor(.white)
                                    .font(.system(size: 13)))
                        }.frame(height: 60)
                        Spacer()
                        Button {
                            withAnimation(.easeIn(duration: 0.4)) {
                                isRun = true
                            }
                            DispatchQueue.main.async{
                                withAnimation {
                                    isRun2 = true
                                }
                            }
                    
                        } label: {
                            ZStack{
                                Rectangle()
                                    
                                    .stroke(Color.white, lineWidth: 2)
                                    .foregroundColor(.black)
                                Text("Run").bold().foregroundColor(.white)
                            }
                        }
                        .frame(width: 70, height: 30)
                        .cornerRadius(2)
                    
                    Spacer()
                    
                
                }
            }else{
                if step <= 3 {
                VStack{
  
                    Text("Welcome to the playground!👋").bold()
                        .transition(.scale)
                        .foregroundColor(.white)
                        
                        
                    Text(subtext).foregroundColor(.white)
                    if step >= 2 {
                        Text(". . .")
                            .bold()
                            .foregroundColor(.white)
                            .padding(.bottom)
                            .font(.system(size: 30))
                        LinearGradient(gradient: Gradient(colors: [Color.purple, Color.purple, Color.white, Color.red, Color.red]), startPoint: .leading, endPoint: .trailing)
                            .mask( Text("In this Playground")
                                    .foregroundColor(.white)
                                    .bold()
                                    .font(.system(size: 20))).frame(height: 30)
                        Text("You can beautify your own artwork\nwith the magic of Artificial Intelligence.✨🤖")
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                        
                        
                    }
                }.offset(y: Variables(step: $step).pass ? -400 : 0)
                }
                if step >= 4 {
                    VStack(spacing: 10){
                        VStack(spacing: 5){
                            Text("Style Transfer in")
                                .foregroundColor(.white)
                                .bold()
                                .font(.system(size: 25))
                            LinearGradient(gradient: Gradient(colors: [Color.init(#colorLiteral(red: 0.7796346545, green: 0.6019737124, blue: 0.8332694173, alpha: 1)), Color.init(#colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)) ]), startPoint: .leading, endPoint: .trailing)
                                .mask(Text("StylizedArt")
                                        .bold()
                                        .foregroundColor(.white)
                                        .font(.system(size: 25)))
                                .frame(width: 130, height: 30)
                        }
                        ZStack{
                            Rectangle()
                                .foregroundColor(.white)
                                .frame(width: 300, height: 2)
                            Rectangle()
                                .foregroundColor(.white)
                                .frame(width: 300, height: 2)
                                .blur(radius: 5)
                        }
                        
                       
                        Text("At the last stage of the playground, you will be able to change the style of your Artwork. So you can bring your own artwork to life using the style of different artworks.🥳")
                            .foregroundColor(.white)
                            .fontWeight(.semibold)
                            .multilineTextAlignment(.center)
                            .frame(width: 400)
                        Text(". . .")
                            .bold()
                            .foregroundColor(.white)
                            .padding(.bottom)
                            .font(.system(size: 30))
                            .frame(height: 10)
                        Text("You will experience style transfer on the other page.👨‍🎨")
                            .foregroundColor(.white)
                            .fontWeight(.semibold)
                            .multilineTextAlignment(.center)
                        
                    }.offset(y: Variables(step: $step).pass ? -400 : 0)
                    
                }
                VStack{
                    HStack{
                        Text("What is in")
                            .bold()
                            .foregroundColor(.white)
                            .font(.system(size: 25))
                        LinearGradient(gradient: Gradient(colors: [Color.init(#colorLiteral(red: 0.7796346545, green: 0.6019737124, blue: 0.8332694173, alpha: 1)), Color.init(#colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)) ]), startPoint: .leading, endPoint: .trailing)
                            .mask(Text("StylizedArt")
                                    .bold()
                                    .foregroundColor(.white)
                                    .font(.system(size: 25)))
                            .frame(width: 130, height: 30)
                        Text(" ?")
                            .bold()
                            .foregroundColor(.white)
                            .font(.system(size: 25))
                        
                    }
                    Text("In Stylized Art, you will be able to liken a artwork \nyou have created to a world famous artwork.🖼")
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                    Text(". . .")
                        .bold()
                        .foregroundColor(.white)
                        .padding(.bottom)
                        .font(.system(size: 30))
                    Text("Once you have chosen the background, you can add the objects, and then you can choose an effect you want and create your artwork.🎨🖌\nFinally, you can add a nice atmosphere with Style Transfer.")
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                        .frame(width: 400)
                        .multilineTextAlignment(.center)
                    
                }.offset(y: Variables(step: $step).pass ? 0 : 400)
                VStack{
                    
                    Spacer()
                    HStack{
                        if step >= 2{
                            Spacer()
                        }
                        Button {
                            
                            withAnimation {
                                if step == 0{
                                    subtext = "Nice experience awaits you."
                                    step += 1
                                }else if step == 1{
                                    pad = 30
                                    step += 1
                                }else if step == 2 {
                                    step += 1
                                }else if step == 4 {
                                    page += 1
                                 }else{
                                    step += 1
                                }
                            }
                        } label: {
                            ZStack{
                                Color.white.opacity(0.9).frame(width: 70, height: 30)
                                Image(systemName: "arrow.forward")
                                    .foregroundColor(.black)
                            }
                        }.cornerRadius(2)
                    }
                    
                }.padding(.bottom , 30).padding(.trailing , pad)

            }

            
                
            
        }.background(Rectangle()
                        .foregroundColor(.white)
                        .frame(width: isRun ? 600 : 270, height: isRun ? 400 : 350)
                        .blur(radius: 3))
        .frame(width: isRun ? 600 : 270, height: isRun ? 400 : 350)
    }
}



/*:
-Purpose of this function, converting _UIImage_ to _CVPixelBuffer_.
 In this way, the image becomes compatible with artificial intelligence.
 */
func pixelBuffer(from image: UIImage) -> CVPixelBuffer? {
    
    UIGraphicsBeginImageContextWithOptions(CGSize(width: 512, height: 512), true, 2.0)
    image.draw(in: CGRect(x: 0, y: 0, width: 512, height: 512))
    _ = UIGraphicsGetImageFromCurrentImageContext()!
    UIGraphicsEndImageContext()

    let attrs = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue, kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
    var pixelBuffer : CVPixelBuffer?
    let status = CVPixelBufferCreate(kCFAllocatorDefault, 512, 512, kCVPixelFormatType_32ARGB, attrs, &pixelBuffer)
    guard (status == kCVReturnSuccess) else {
        return nil
    }

    CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
    let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer!)

    let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
    let context = CGContext(data: pixelData, width: 512, height: 512, bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer!), space: rgbColorSpace, bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue)

    context?.translateBy(x: 0, y: 512)
    context?.scaleBy(x: 1.0, y: -1.0)

    UIGraphicsPushContext(context!)
    image.draw(in: CGRect(x: 0, y: 0, width: 512, height: 512))
    UIGraphicsPopContext()
    CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))

    return pixelBuffer
}

PlaygroundPage.current.setLiveView(ContentView().frame(width: 600 , height: 400))
